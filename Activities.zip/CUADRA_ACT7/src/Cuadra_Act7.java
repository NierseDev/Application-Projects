import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class Cuadra_Act7 {
    public static void main(String[] args) throws IOException {
        Motorcycle instCycle = new Motorcycle();
        InputStreamReader io = new InputStreamReader(System.in);
        BufferedReader input = new BufferedReader(io);

        System.out.print("Brand of the Motorcycle: ");
        instCycle.brand = String.valueOf(input.readLine());
        System.out.print("Model of the Motorcycle: ");
        instCycle.model = String.valueOf(input.readLine());
        System.out.print("Color of the Motorcycle: ");
        instCycle.color = String.valueOf(input.readLine());
        System.out.print("Price of the Motorcycle: ");
        instCycle.price = Integer.parseInt(input.readLine());
        System.out.print("Mileage of the Motorcycle: ");
        instCycle.mileage = Double.parseDouble(input.readLine());

        System.out.println("Object Motorcycle:");
        System.out.println(instCycle.brand);
        System.out.println(instCycle.model);
        System.out.println(instCycle.color);
        System.out.println(instCycle.price);
        System.out.println(instCycle.mileage);

        System.out.print("\nMethod 1:");
        instCycle.Start();

        System.out.print("\nMethod 2: ");
        instCycle.Stop();
    }
}