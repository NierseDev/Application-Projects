public class Motorcycle {
    String brand, model, color;
    int price;
    double mileage;

    static void Start() {
        System.out.println("Vroom, Vroom!");
    }

    static void Stop() {
        System.out.println("Motorcycle Stopped");
    }
}
