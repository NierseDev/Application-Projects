import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        String name = "", fName = "", lName = "", gender = "", married;
        int age = 0;
        boolean isMarried = false;

        InputStreamReader input = new InputStreamReader(System.in);
        BufferedReader dataInput = new BufferedReader(input);

        try {
            System.out.println("Enter your First Name:");
            fName = dataInput.readLine();
            if (!fName.matches(".*\\d.*")) {

            } else {
                throw new Exception("Invalid Input, Please provide your first name!");
            }

            System.out.println("Enter your Last Name:");
            lName = dataInput.readLine();
            if (!lName.matches(".*\\d.*")) {
                name = fName + " " + lName;
            } else {
                throw new Exception(("Invalid Input, Please provide your last name!"));
            }

            System.out.println("Gender: Male or Female");
            System.out.println("What is your gender:");
            gender = dataInput.readLine();

            gender = String.valueOf(gender.charAt(0));
            gender = gender.toUpperCase();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        try {
            System.out.println("Enter your age:");
            age = Integer.parseInt(dataInput.readLine());

        } catch (IOException e) {
            System.out.println("Invalid Input, Please provide your age!");
        }

        try {
            System.out.println("Are you married, " + name + " (y or n)?");
            married = dataInput.readLine();
            if (married.equals("y")) {
                isMarried = true;
            }

        } catch (IOException e) {
            System.out.println("Invalid Input!");
        }

        if (age >= 20 && isMarried == true) {
            if (gender.equals("M")) {
                System.out.println("Then I shall call you, Mr. " + lName);
            } else {
                System.out.println("Then I shall call you, Mrs. " + lName);
            }
        } else if (age >= 20 || isMarried == false) {
            if (gender.equals("M")) {
                System.out.println("Then I shall call you, Mr. " + lName);
            } else {
                System.out.println("Then I shall call you, Ms. " + lName);
            }
        }
    }
}