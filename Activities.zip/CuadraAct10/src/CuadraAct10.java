class Television {
    private static int count = 0;
    private String brandName;
    private String type;
    private int screenSize;
    private int weight;
    private String screenResolution;
    private double price;

    public Television() {
        count++;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getBrandName() {
        return this.brandName;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return this.type;
    }

    public void setScreenSize(int screenSize) {
        this.screenSize = screenSize;
    }

    public int getScreenSize() {
        return this.screenSize;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getWeight() {
        return this.weight;
    }

    public void setScreenResolution(String screenResolution) {
        this.screenResolution = screenResolution;
    }

    public String getScreenResolution() {
        return this.screenResolution;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getPrice() {
        return this.price;
    }

    public void loading() {
        System.out.println("Loading.....");
    }

    public void displayOptions() {
        System.out.println("Menu\n| TV | Youtube | Netflix | Disney | Hulu | Spotify |\nYoutube Selected");
    }

    public void lowInternetConnection() {
        System.out.println("Low Internet Connection! Cannot continue to play Youtube video");
    }

    public static int getCount() {
        return count;
    }
}

public class CuadraAct10 {
    public static void main(String[] args) {
        Television tv1 = new Television();

        tv1.setBrandName("Samsung");
        System.out.println("\nTV1 Brand Name: " + tv1.getBrandName());

        tv1.setType("LED");
        System.out.println("TV1 Type: " + tv1.getType());

        tv1.setScreenSize(32);
        System.out.println("TV1 Screen Size: " + tv1.getScreenSize() + " inch");

        tv1.setWeight(2);
        System.out.println("TV1 Weight: " + tv1.getWeight() + "kg");

        tv1.setScreenResolution("4k 1920x1080");
        System.out.println("TV1 Screen Resolution: " + tv1.getScreenResolution());

        tv1.setPrice(18999.99);
        System.out.println("TV1 Price: " + tv1.getPrice() + "PHP\n");

        tv1.loading();
        tv1.displayOptions();
        tv1.lowInternetConnection();

        System.out.println("\n----------------------------------------\n");

        Television tv2 = new Television();

        tv2.setBrandName("LG");
        System.out.println("TV2 Brand Name: " + tv2.getBrandName());

        tv2.setType("Smart");
        System.out.println("TV2 Type: " + tv2.getType());

        tv2.setScreenSize(55);
        System.out.println("TV2 Screen Size: " + tv2.getScreenSize() + " inch");

        tv2.setPrice(89500.99);
        System.out.println("TV2 Price: " + tv2.getPrice());

        System.out.println("\n----------------------------------------\n");

        Television tv3 = new Television();

        tv3.setBrandName("TLC");
        System.out.println("TV3 Brand Name: " + tv3.getBrandName());

        tv3.setType("Smart");
        System.out.println("TV3 Type: " + tv3.getType());

        tv3.setScreenSize(65);
        System.out.println("TV3 Screen Size: " + tv3.getScreenSize() + " inch");

        tv3.setScreenResolution("4k 3840x2160");
        System.out.println("TV3 Screen Resolution: " + tv3.getScreenResolution());

        tv3.setPrice(102900.99);
        System.out.println("TV3 Price: " + tv3.getPrice());

        System.out.println("\n----------------------------------------\n");

        System.out.println("Number of Television objects: " + Television.getCount());
    }
}