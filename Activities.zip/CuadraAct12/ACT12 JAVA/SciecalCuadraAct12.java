class Calculator {
    // Values
    protected int c, s;

    // Parameter Constructor
    public Calculator(int c, int s) {
        this.c = c;
        this.s = s;
    }

    // Method
    public void Display() {
        System.out.println("Calculator perfroms Arithmetic Operations!");

    }
    public void addNum() {
        int sum = c + s;
        System.out.println(sum);
    }
}

public class SciecalCuadraAct12 extends Calculator {
    
    // Parameter Constructor
    public SciecalCuadraAct12(int c, int s) {
        super(c, s);
    }

    // Override Method
    @Override
    public void Display() {
        System.out.println("Scientific Calculator is used for advance or complicate math problems");
    }

    // Method
    public void subNum() {
        int diff =  c - s;
        System.out.println("Difference: " + diff);
    }
    public void prodNum() {
        int prod = c * s;
        System.out.println("Product: " + prod);
    }
    public void quotientNum() {
        int quot = c / s;
        System.out.println("Quotient: " + quot);
    }
    public static void main(String[] args) {
        Calculator calc1 = new Calculator(10, 5);
        calc1.Display();
        SciecalCuadraAct12 calc2 = new SciecalCuadraAct12(10, 5);
        calc2.Display();
        calc2.addNum();
        calc2.subNum();
        calc2.prodNum();
        calc2.quotientNum();
    }
}