class Oven {
    // Attributes
    String brand;
    String desc; // "With rotisserie function, 60 Minutes timer with a cooking end signal: Tik! Roasted Chicken Done Cooking"
    int capacity;
    int price;
    int eConsump;

    // Constructor
    public Oven(String n, String d, int c, int p, int eC) {
        brand = n;
        desc = d;
        price = p;
        capacity = c;
        eConsump = eC;
    }

    // Methods
    int timer; // Variable Declaration
    public void setTime(int minutes) {
        timer = minutes;
        System.out.println("Time set: " + minutes + " minutes");
    }

    public void notifOwner() {
        System.out.println("Tik! Roasted Chicken Done Cooking\n");
    }
}

public class CuadraAct9 {
    public static void main(String[] args) {
        // Object 1
        Oven KYOWA = new Oven("KYOWA", "With rotisserie function, 60 Minutes timer with a cooking end signal:", 28, 4500, 600);
        KYOWA.setTime(60);
        System.out.println("Oven Name: " + KYOWA.brand);
        System.out.println("Capacity: " + KYOWA.capacity + "L");
        System.out.println("Price: " + KYOWA.price);
        System.out.println("Electrical Consumption: " + KYOWA.eConsump + " Watts");
        System.out.println("Description: " + KYOWA.desc);
        KYOWA.notifOwner();

        // Object 2
        Oven CAMEL = new Oven("CAMEL", "null", 40, 0, 1000);
        System.out.println("Oven Name: " + CAMEL.brand);
        System.out.println("Capacity: " + CAMEL.capacity + "L");
        System.out.println("Price: " + CAMEL.price);
        System.out.println("Electrical Consumption: " + CAMEL.eConsump + " Watts");
        System.out.println("Description: " + CAMEL.desc);
        CAMEL.notifOwner();

        // Object 3
        Oven LG = new Oven("LG", "null", 40, 5100, 0);
        System.out.println("Oven Name: " + LG.brand);
        System.out.println("Capacity: " + LG.capacity + "L");
        System.out.println("Price: " + LG.price);
    }
}